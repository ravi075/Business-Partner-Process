sap.ui.define([
    "sap/ui/core/mvc/Controller",
    'sap/m/MessageToast',
    'sap/m/MessageBox'
],
function (Controller, MessageToast, MessageBox) {
    "use strict";

    return Controller.extend("bpapproval.controller.Approval", {
        onInit: function () {

        },

        onApprovePress: function () {
            // var that = this;
            MessageBox.confirm("Are you sure you want to approve?", {
              actions: [MessageBox.Action.YES, MessageBox.Action.NO],
              onClose: function (oAction) {
                if (oAction === MessageBox.Action.YES) {
                  MessageToast.show("Approved successfully");
                }
              }
            });
        },
        onRejectPress: function(){
            MessageBox.confirm("Are you realy want to reject?", {
                action: [MessageBox.Action.YES, MessageBox.Action.NO],
                onClose: function(oAction){
                    if (oAction === MessageBox.Action.OK){
                        MessageToast.show("Rejected successfully");
                    }
                }
            });
                }
    });
});
