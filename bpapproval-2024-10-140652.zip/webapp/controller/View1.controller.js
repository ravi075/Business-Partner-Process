sap.ui.define([
    "sap/ui/core/mvc/Controller",
    'sap/ui/model/odata/v2/ODataModel',
    'sap/m/MessageToast',
    'sap/m/MessageBox',
    'sap/ui/model/Filter',
    'sap/ui/model/FilterOperator',
    'sap/ui/core/format/DateFormat'
    // "sap/m/PDFViewer",
    // "sap/ui/table/rowmodes/Auto",
	// "sap/m/PDFViewerDisplayType"
],
    function (Controller,
	ODataModel,
	MessageToast,
	MessageBox,
	Filter,
	FilterOperator,
	DateFormat,
) {
        "use strict";
        var dateFormatCount = 0;
        var k = 0;
        var level = '';

        // for Date validations
        var oDateFormatCount = 0;
        var oPrevProcessing = '';
        var d = 3;


        return Controller.extend("bpapproval.controller.View1", {
            onInit: function () {
                dateFormatCount = 0;
                oPrevProcessing = '';
                this._onObjectMatched();
            },

            _onObjectMatched: function () {
                var sServiceUrl = "/sap/opu/odata/sap/ZBP_APPROVER_SRV";
                // var oDataModel = new ODataModel(sServiceUrl, true);
                var oDataModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);

                var dataUrl = "/Approver_LevelSet";
                oDataModel.read(dataUrl, {
                    success: function (oData1) {
                        level = oData1.results[0].Applevel //set approval level 
                        var oJson = new sap.ui.model.json.JSONModel({
                            "EmpTAppr": oData1.results
                        });
                        this.getView().setModel(oJson, "EmpAppr");
                        if(level==="L1"){
                            // this.byId("idDownloadFormButton").setVisible(false);
                            // this.byId("idMailButton").setVisible(false);    
                         }
                    }.bind(this),
                    error: function (error) {
                    }
                });
                this.getView().getModel("EmpAppr");
                var dataUrl = "/zbp_approverSet";
                oDataModel.read(dataUrl, {
                    success: function (oData) {
                        this.processData(oData.results);
                        // this.processData();
                        // var oJson = new sap.ui.model.json.JSONModel({
                        //     "EmpTData": oData.results
                        // });

                        // this.getView().setModel(oJson, "EmpTM1");
                        // for(var i=0; i<oData.results.length; i++){
                        // this.dateFormatter(this.getView().getModel("EmpTM1").getData().EmpTData[i].Timestamp);
                        // }
                    }.bind(this),
                    error: function (error) {
                    }
                });

                var dataUrl = "/zbp_refnoSet";
                oDataModel.read(dataUrl, {
                    success: function (oData) {
                        var oJson = new sap.ui.model.json.JSONModel({
                            "EmpTRef": oData.results
                        });
                        this.getView().setModel(oJson, "EmpRef")

                    }.bind(this),
                    error: function (error) {
                    }
                });


            },

            processData: function (aData) {
                // Create a map to track occurrences of each Customerno
                var oCustomerCount = {};
                var aFilteredData = [];

                // Count occurrences of each Customerno
                aData.forEach(function (oItem) {
                    var sCustomerno = oItem.Customerno;
                    if (!oCustomerCount[sCustomerno]) {
                        oCustomerCount[sCustomerno] = 0;
                    }
                    oCustomerCount[sCustomerno]++;
                });

                // Filter data based on the condition
                aData.forEach(function (oItem) {
                    var sCustomerno = oItem.Customerno;
                    var iCount = oCustomerCount[sCustomerno];

                    // if (iCount > 1) {
                    //     // If duplicate, include only items with Applevel 'l1'
                    //     if (oItem.Applevel === 'L1') {
                    //         aFilteredData.push(oItem);
                    //     }
                    // } else {
                    //     // If not duplicate, include the item
                    //     aFilteredData.push(oItem);
                    // }
                    if (level === 'L1') {
                        if (iCount > 1) {
                            // If duplicate and level is 'L1', include only items with Applevel 'L1'
                            if (oItem.Applevel === 'L1') {
                                aFilteredData.push(oItem);
                            }
                        } else {
                            // If no duplicates, include the item
                            aFilteredData.push(oItem);
                        }
                    } else if (level === 'L2') {
                        if (iCount > 1) {
                            // If duplicate and level is 'L2', include only items with Applevel 'L2' or 'L1' if not 'L2'
                            if (oItem.Applevel === 'L2') {
                                aFilteredData.push(oItem);
                            } else {
                                // If there are no 'L2' records, include 'L1' records
                                var hasL2 = aData.some(function (item) {
                                    return item.Customerno === sCustomerno && item.Applevel === 'L2';
                                });
                                if (!hasL2 && oItem.Applevel === 'L1' && oItem.Status === "Approved") {
                                    aFilteredData.push(oItem);



                                }
                            }
                        } else if (iCount === 1) {

                            // If no duplicates and level is 'L2', add no data
                            // This block is intentionally left empty
                        }
                    }
                });

                // Sort the filtered data based on Customerno
                aFilteredData.sort(function (a, b) {
                    return parseInt(a.Customerno, 10) - parseInt(b.Customerno, 10);
                });

                //for changing applevel and status remarks filed based on applevel
                if (level === "L2") {
                    for (var i = 0; i < aFilteredData.length; i++) {
                        if (aFilteredData[i].Applevel === "L1") {
                            aFilteredData[i].Applevel = "L2";
                            // aFilteredData[i].Status = "Initiated";
                            aFilteredData[i].Status = "Pending"
                            aFilteredData[i].Remarks = "";
                        }
                    }
                } else {
                    for (var i = 0; i < aFilteredData.length; i++) {
                        aFilteredData[i].Applevel = "L1";
                    }
                }

                // Set the filtered data to the model
                var oJson = new sap.ui.model.json.JSONModel({
                    "EmpTData": aFilteredData
                });

                this.getView().setModel(oJson, "EmpTM1");


                // Making a Deep Clone of the Original Data to Avoid Referencing of the Data
                var oClonedData = JSON.parse(JSON.stringify(aFilteredData));

                var oJsonOriginalData = new sap.ui.model.json.JSONModel({
                    "EmpOrgData": oClonedData
                });
                this.getView().setModel(oJsonOriginalData, "EmpOrgDataMDL");
                var oData = this.getView().getModel("EmpTM1").getData().EmpTData;
                for (var i = 0; i < oData.length; i++) {
                    var oFilterData = this.getView().getModel("EmpTM1").getData().EmpTData[i].Timestamp;
                    this.dateFormatter(oFilterData, i);
                }


                this.callPreviousProcessingStatus();
                var oDataOriginal = this.getView().getModel("EmpOrgDataMDL").getData().EmpOrgData;
                for (var i = 0; i < oDataOriginal.length; i++) {
                    var oMainData = oDataOriginal[i].Timestamp;
                    this.dateFormatter(oMainData, i);
                }

            },
            callPreviousProcessingStatus: function () {
                oPrevProcessing = 'Yes';
            },

            dateFormatter: function (oTimestamp, i) {
                var oYear = oTimestamp.substring(0, 4);
                var oMonth = oTimestamp.substring(4, 6);
                var oDay = oTimestamp.substring(6, 8);
                var oHour = oTimestamp.substring(8, 10);
                var oMinute = oTimestamp.substring(10, 12);
                var oSecond = oTimestamp.substring(12, 14);

                var oFormatDate = oYear + "/" + oMonth + "/" + oDay + " " + oHour + ":" + oMinute + ":" + oSecond;
                if (oPrevProcessing == '') {
                    if (dateFormatCount >= 0) {
                        this.getView().getModel("EmpTM1").getData().EmpTData[i].Timestamp = oFormatDate;
                        // k++;
                        dateFormatCount++;
                    } else {
                        this.getView().getModel("EmpTM1").getData().Timestamp = oFormatDate;
                    }
                } else if (oPrevProcessing == 'Yes') {
                    if (oDateFormatCount >= 0) {
                        this.getView().getModel("EmpOrgDataMDL").getData().EmpOrgData[i].Timestamp = oFormatDate;
                        // k++;
                        oDateFormatCount++;
                    } else {
                        this.getView().getModel("EmpOrgDataMDL").getData().EmpOrgData[i].Timestamp = oFormatDate;
                    }
                }
            },

            onValueHelpRequestF4: function () {
                if (!this._oDialogF4) {
                    this._oDialogF4 = sap.ui.xmlfragment("bpapproval.view.Reference", this);
                    this.getView().addDependent(this._oDialogF4);
                }
                this._oDialogF4.getBinding("items").filter([]);
                this._oDialogF4.open();
            },

            onValueHelpSearchF4: function (oEvent) {
                var sValue = oEvent.getParameter("value");
                var formattedValue = sValue.padStart(10, '0');
                var oFilter = new Filter("Customerno", FilterOperator.EQ, formattedValue);
                if (formattedValue) {
                    oEvent.getSource().getBinding("items").filter([oFilter]);
                } else {
                    oEvent.getSource().getBinding("items").filter([]);
                }
            },

            onValueHelpCloseF4: function (oEvent) {
                var sValue = oEvent.getParameter("selectedItem").getTitle();
                // var oSelectedItem = oEvent.getParameter("selectedItem");
                if (sValue) {
                    this.getView().getModel("EmpRef").setProperty("/Customerno", sValue);
                }
            },
            onFilterPress: function () {
                var oView = this.getView();
                var sCustomerno = oView.byId("idRefNumInput").getValue().trim();
                var sStatus = oView.byId("statusComboBox").getValue();
                var oDateRangeSelection = oView.byId("dateRangeSelection"); // Get the DateRangeSelection control

                // Retrieve the selected date range
                var oStartDate = oDateRangeSelection.getDateValue();
                var oEndDate = oDateRangeSelection.getSecondDateValue();

                // Convert dates to ISO strings if they are not null
                var sStartDate = oStartDate ? oStartDate.toISOString() : null;
                var sEndDate = oEndDate ? oEndDate.toISOString() : null;

                // Retrieve Original Data from the Model
                var originalData = this.getView().getModel("EmpOrgDataMDL").getData().EmpOrgData;

                // Cloning Original Data to avoid Referencing
                var oClonedRefData = JSON.parse(JSON.stringify(originalData));

                // Copying Cloned Data to Original Binded Model
                var oData = (this.getView().getModel("EmpTM1").getData().EmpTData = oClonedRefData);

                // Check if at least one field is selected
                if (!sCustomerno && !sStatus && !sStartDate && !sEndDate) {
                    var oJsonModel = new sap.ui.model.json.JSONModel({
                        "EmpTData": oData
                    });
                    this.getView().setModel(oJsonModel, "EmpTM1");

                    return;
                }

                // Convert timestamp to ISO format for comparison
                function parseTimestamp(timestamp) {
                    var parts = timestamp.split(' ');
                    var dateParts = parts[0].split('/');
                    var timeParts = parts[1].split(':');
                    var date = new Date(
                        dateParts[0], // Year
                        dateParts[1] - 1, // Month (0-based index)
                        dateParts[2], // Day
                        timeParts[0], // Hours
                        timeParts[1], // Minutes
                        timeParts[2]  // Seconds
                    );
                    return date.toISOString();
                }

                // Filter data based on the criteria
                var aFilteredData = oData.filter(function (oItem) {
                    var bMatchCustomerno = sCustomerno ? oItem.Customerno === sCustomerno : true;
                    var bMatchStatus = sStatus ? oItem.Status === sStatus : true;

                    // Convert timestamp to ISO string for comparison
                    var sItemTimestamp = parseTimestamp(oItem.Timestamp); // Convert timestamp to ISO string
                    var bMatchDateRange = true;

                    if (sStartDate && sEndDate) {
                        bMatchDateRange = sItemTimestamp >= sStartDate && sItemTimestamp <= sEndDate;
                    } else if (sStartDate) {
                        bMatchDateRange = sItemTimestamp >= sStartDate;
                    } else if (sEndDate) {
                        bMatchDateRange = sItemTimestamp <= sEndDate;
                    }

                    return bMatchCustomerno && bMatchStatus && bMatchDateRange;
                });

                // Set the filtered data to the model
                var oJsonModel = new sap.ui.model.json.JSONModel({
                    "EmpTData": aFilteredData
                });
                this.getView().setModel(oJsonModel, "EmpTM1");
                oJsonModel.refresh(); // This is usually not needed, as the model update should be automatic
            },

            // for preview and download the file 
            // onDownloadPDF111: function (oEvent) {
            //     var pData1 = this.getView().getModel("EmpTM1").getData().EmpTData;
            //     var oTable = this.byId("tb1");
            //     var aSelectedIndices = oTable.getSelectedIndices();
            //     var pData = [];
            //     if (aSelectedIndices.length <= 0) {
            //         sap.m.MessageBox.error("Please select at list one record");
            //         return;
            //     }
            //     // Loop through the selected indices and push the corresponding rows to newData
            //     for (var i = 0; i < aSelectedIndices.length; i++) {
            //         var index = aSelectedIndices[i];
            //         if (index >= 0 && index < pData1.length) {
            //             pData.push(pData1[index]);
            //             var Customerno = pData[i].Customerno;
            //             if(pData[i].Status !=="Approved"){
            //                 sap.m.MessageBox.error("You can download whose BP status is approved");
            //                 return
            //             }
            //         }
            //     }
            //     var sServiceUrl = this.getOwnerComponent().getModel().sServiceUrl;
            //     var sPath = sServiceUrl+"/BP_FormSet(" + "'" + Customerno + "'" + ")" + "/$value";
            //     var oPDFViewer = new sap.m.PDFViewer({
            //         // displayType: "Auto",
            //         // PDFViewerDisplayType: "Auto",
            //         // showDownloadButton: false,
            //         isTrustedSource: false,
            //         source: sPath,
            //         title: "View PDF Document",
            //         showDownloadButton: false
            //     });
            //     this.getView().addDependent(oPDFViewer);
            //     var sSource = sPath;
            //     oPDFViewer.setSource(sSource);
            //     oPDFViewer.open(); 
            // },
            

            onDownloadPDF: async function () {
                var pData1 = this.getView().getModel("EmpTM1").getData().EmpTData;
                var oTable = this.byId("tb1");
                var aSelectedIndices = oTable.getSelectedIndices();
                var pData = [];
                
                if (aSelectedIndices.length <= 0) {
                    sap.m.MessageBox.error("Please select at least one record");
                    return;
                }
                
                // Loop through the selected indices and push the corresponding rows to newData
                for (var i = 0; i < aSelectedIndices.length; i++) {
                    var index = aSelectedIndices[i];
                    if (index >= 0 && index < pData1.length) {
                        pData.push(pData1[index]);
                        if (pData[i].Status !== "Approved") {
                            sap.m.MessageBox.error("You can download documents only for records with an approved status");
                            return;
                        }
                    }
                }
            
                for (let j = 0; j < pData.length; j++) {
                    (function(Customerno) {
                        var sServiceUrl = this.getOwnerComponent().getModel().sServiceUrl;
                        var sPath = sServiceUrl + "/BP_FormSet('" + Customerno + "')/$value";
            
                        // Use fetch to get the PDF file
                        fetch(sPath)
                            .then(function (response) {
                                if (!response.ok) {
                                    throw new Error('Network response was not ok');
                                }
                                return response.blob(); // Get the response as a Blob
                            })
                            .then(function (blob) {
                                // Create a link element and trigger the download
                                var link = document.createElement('a');
                                link.href = URL.createObjectURL(blob);
                                link.download = Customerno + ".pdf"; // Set the filename for the download
                                document.body.appendChild(link);
                                link.click(); // Trigger the download
                                document.body.removeChild(link); // Remove the link element
                            })
                            .catch(function (error) {
                                sap.m.MessageBox.error("Error downloading PDF: " + error.message);
                            });
                    }).call(this, pData[j].Customerno);
                }
            },
             
            onMail: function (oEvent) {
                var pData1 = this.getView().getModel("EmpTM1").getData().EmpTData;
                var oTable = this.byId("tb1");
                var aSelectedIndices = oTable.getSelectedIndices();
                var pData = [];
                var approvedCustomerNumbers = [];
                if (aSelectedIndices.length <= 0) {
                    sap.m.MessageBox.error("Please select at list one record");
                    return;
                }
                // Loop through the selected indices and push the corresponding rows to newData
                for (var i = 0; i < aSelectedIndices.length; i++) {
                    var index = aSelectedIndices[i];
                    if (index >= 0 && index < pData1.length) {
                        pData.push(pData1[index]);
                        var Customerno = pData[i].Customerno;
                        if(pData[i].Status !=="Approved"){
                            sap.m.MessageBox.error("You can download whose BP status is approved");
                            return
                        }else {
                            // If approved, add to the customer numbers array
                            approvedCustomerNumbers.push(Customerno);
                        }
                    }
                } 
                var sServiceUrl = this.getOwnerComponent().getModel().sServiceUrl;
                // var sPath = sServiceUrl + "/BP_FormSet('" + Customerno + "')/$value";
                var i=1;
                var Formtype = "p";
                // Create an AJAX request to fetch the PDF
                approvedCustomerNumbers.forEach(function(Customerno) {
                var sPath = sServiceUrl + "/Zbp_mailFormSet('" + Customerno + "')/$value";
                $.ajax({
                    url: sPath,
                    method: 'GET',
                    headers: {
                        "Accept": "application/pdf"
                    },
                    success: function (data) {
                        // Do nothing with the data to prevent downloading
                        // Optionally, log to console or handle as necessary
                        // console.log("PDF generated successfully, but not downloading.");
                        if(i=== pData.length){
                            sap.m.MessageBox.success("PDF send on mail successfully");
                        }
                        // sap.m.MessageBox.success("PDF send on mail successfully");
                        i++
                    },
                    error: function (error) {
                        // Handle the error response here
                        sap.m.MessageBox.error("Error fetching the PDF: " + error.statusText);
                    }
                });
                 });
            },

            onMail1: function(){
                var pData1 = this.getView().getModel("EmpTM1").getData().EmpTData;
                var oTable = this.byId("tb1");
                var aSelectedIndices = oTable.getSelectedIndices();
                var pData = [];
                var approvedCustomerNumbers = [];
            
                if (aSelectedIndices.length <= 0) {
                    sap.m.MessageBox.error("Please select at least one record");
                    return;
                }
            
                // Loop through the selected indices and push the corresponding rows to newData
                for (var i = 0; i < aSelectedIndices.length; i++) {
                    var index = aSelectedIndices[i];
                    if (index >= 0 && index < pData1.length) {
                        pData.push(pData1[index]);
                        var Customerno = pData[i].Customerno;
            
                        // Check if the status is approved
                        if (pData[i].Status !== "Approved") {
                            sap.m.MessageBox.error("You can only download records whose BP status is approved");
                            return;
                        } else {
                            // If approved, add to the customer numbers array
                            approvedCustomerNumbers.push(Customerno);
                        }
                    }
                }
                let payload = {
                    Customerno: "74"
                }
                var oModel = this.getOwnerComponent().getModel(),
                        oBusy = new sap.m.BusyDialog();
                    oModel.create("/BP_FormSet", payload, {
                        success: function (oData) {
                            new sap.m.MessageBox.success("Approved record has been updated successfully.");
                            oBusy.close();
                            this.getView().getModel("EmpTM1").refresh;

                        },
                        error: function (error) {
                            // oBusy.close();
                            var responseText = JSON.parse(error.responseText);
                            var msg = responseText.error.message.value;
                            sap.m.MessageBox.error(msg);
                            oBusy.close();
                        }
                    });
                
            },

            onSubmitButtonPress: function () {
                var tData1 = this.getView().getModel("EmpTM1").getData().EmpTData;
                var oTable = this.byId("tb1");
                var aSelectedIndices = oTable.getSelectedIndices();
                var tData = [];
                if (aSelectedIndices.length <= 0) {
                    sap.m.MessageBox.error("Please select at list one record");
                    return;
                }
                // Loop through the selected indices and push the corresponding rows to newData
                for (var i = 0; i < aSelectedIndices.length; i++) {
                    var index = aSelectedIndices[i];
                    if (index >= 0 && index < tData1.length) {
                        tData.push(tData1[index]);
                    }
                    if (tData1[i].Remarks === "") {
                        sap.m.MessageBox.error("Remarks is mandatory Field")
                        return
                    }
                }
                //to check approval level 
                var appData = this.getView().getModel("EmpAppr").getData().EmpTAppr;
                if (appData[0].Applevel === "L1") {

                    let aitemss = []
                    for (var i = 0; i < tData.length; i++) {
                        aitemss.push({
                            Customerno: String(tData[i].Customerno),
                            Custacctgroup: String(tData[i].Custacctgroup),
                            Pannumber: String(tData[i].Pannumber),
                            Title: String(tData[i].Title),
                            Name: String(tData[i].Name),
                            Street: String(tData[i].Street),
                            City: String(tData[i].City),
                            District: String(tData[i].District),
                            State: String(tData[i].State),
                            Postalcode: String(tData[i].Postalcode),
                            Country: String(tData[i].Country),
                            Language: String(tData[i].Language),
                            Searchterm: String(tData[i].Searchterm),
                            Companycode: String(tData[i].Companycode),
                            Reconcacc: String(tData[i].Reconcacc),
                            Salesorg: String(tData[i].Salesorg),
                            Distchannel: String(tData[i].Distchannel),
                            Division: String(tData[i].Division),
                            Currency: String(tData[i].Currency),
                            Pricingproc: String(tData[i].Pricingproc),
                            Shippingcon: String(tData[i].Shippingcon),
                            Custgroup: String(tData[i].Custgroup),
                            Salesdist: String(tData[i].Salesdist),
                            Salesoffice: String(tData[i].Salesoffice),
                            Pricegroup: String(tData[i].Pricegroup),
                            Incoterms: String(tData[i].Incoterms),
                            Incotermsloc: String(tData[i].Incotermsloc),
                            Paymentterm: String(tData[i].Paymentterm),
                            Applevel: "L1",
                            Timestamp: "",
                            Status: "Approved",
                            Remarks: String(tData[i].Remarks)
                        });
                    }
                    let payload = {
                        "Dummy": "X",
                        "Tobpitems": aitemss
                    }
                    // return;
                    /**
                     * @type {sap.ui.model.odata.v2.ODataModel}
                     */
                    var oModel = this.getOwnerComponent().getModel(),
                        oBusy = new sap.m.BusyDialog();
                    oModel.create("/CreateDummySet", payload, {
                        success: function (oData) {
                            new sap.m.MessageBox.success("Approved record has been updated successfully.");
                            oBusy.close();
                            this.getView().getModel("EmpTM1").refresh;

                        },
                        error: function (error) {
                            // oBusy.close();
                            var responseText = JSON.parse(error.responseText);
                            var msg = responseText.error.message.value;
                            sap.m.MessageBox.error(msg);
                            oBusy.close();
                        }
                    });
                } else if (appData[0].Applevel === "L2") {
                    let aitemss = []
                    for (var i = 0; i < tData.length; i++) {
                        aitemss.push({
                            Customerno: String(tData[i].Customerno),
                            Custacctgroup: String(tData[i].Custacctgroup),
                            Pannumber: String(tData[i].Pannumber),
                            Title: String(tData[i].Title),
                            Name: String(tData[i].Name),
                            Street: String(tData[i].Street),
                            City: String(tData[i].City),
                            District: String(tData[i].District),
                            State: String(tData[i].State),
                            Postalcode: String(tData[i].Postalcode),
                            Country: String(tData[i].Country),
                            Language: String(tData[i].Language),
                            Searchterm: String(tData[i].Searchterm),
                            Companycode: String(tData[i].Companycode),
                            Reconcacc: String(tData[i].Reconcacc),
                            Salesorg: String(tData[i].Salesorg),
                            Distchannel: String(tData[i].Distchannel),
                            Division: String(tData[i].Division),
                            Currency: String(tData[i].Currency),
                            Pricingproc: String(tData[i].Pricingproc),
                            Shippingcon: String(tData[i].Shippingcon),
                            Custgroup: String(tData[i].Custgroup),
                            Salesdist: String(tData[i].Salesdist),
                            Salesoffice: String(tData[i].Salesoffice),
                            Pricegroup: String(tData[i].Pricegroup),
                            Incoterms: String(tData[i].Incoterms),
                            Incotermsloc: String(tData[i].Incotermsloc),
                            Paymentterm: String(tData[i].Paymentterm),
                            Applevel: "L2",
                            Timestamp: "",
                            Status: "Approved",
                            Remarks: String(tData[i].Remarks)
                        });
                    }
                    let payload = {
                        "Dummy": "X",
                        "Tobpitems": aitemss
                    }
                    // return;
                    /**
                     * @type {sap.ui.model.odata.v2.ODataModel}
                     */
                    var oModel = this.getOwnerComponent().getModel(),
                        oBusy = new sap.m.BusyDialog();
                    oModel.create("/CreateDummySet", payload, {
                        success: function (oData) {
                            new sap.m.MessageBox.success("Approved record updated successfully.");
                            oBusy.close();
                            this.getView().getModel("EmpTM1").refresh;
                        },
                        error: function (error) {
                            // oBusy.close();
                            // var responseText = JSON.parse(error.responseText);
                            // var msg = responseText.error.message.value;
                            // MessageBox.error(msg);
                            oBusy.close();

                            var responseText = error.responseText;
                            if (responseText) {
                                try {
                                    // Attempt to parse the responseText as JSON
                                    var responseJson = JSON.parse(responseText);
                                    var msg = responseJson.error.message.value;
                                    sap.m.MessageBox.error(msg);
                                } catch (e) {
                                    // If parsing fails, handle the error gracefully
                                    new sap.m.MessageBox.error("An error occurred: " + msg);
                                }
                            } else {
                                // Handle cases where responseText is undefined or empty
                                new sap.m.MessageBox.error("An unknown error occurred.");
                            }
                        }
                    });
                }
            },

            onRejectPress: function () {
                var tData1 = this.getView().getModel("EmpTM1").getData().EmpTData;
                var oTable = this.byId("tb1");
                var aSelectedIndices = oTable.getSelectedIndices();
                var tData = [];
                if (aSelectedIndices.length <= 0) {
                    sap.m.MessageBox.error("Please select at list one record");
                    return;
                }
                // Loop through the selected indices and push the corresponding rows to newData
                for (var i = 0; i < aSelectedIndices.length; i++) {
                    var index = aSelectedIndices[i];
                    if (index >= 0 && index < tData1.length) {
                        tData.push(tData1[index]);
                    }
                }
                //To make remarks as a mandatory field
                // for(var j=0; j<tData.length; j++){
                //     if(tData[j].Remarks === "")
                //         sap.m.MessageBox.error("Remarks is mandatory field");
                //         return
                //     }
                //to check approval level 
                var appData = this.getView().getModel("EmpAppr").getData().EmpTAppr;
                if (appData[0].Applevel === "L1") {
                    let aitemss = []
                    for (var i = 0; i < tData.length; i++) {
                        aitemss.push({
                            Customerno: String(tData[i].Customerno),
                            Custacctgroup: String(tData[i].Custacctgroup),
                            Pannumber: String(tData[i].Pannumber),
                            Title: String(tData[i].Title),
                            Name: String(tData[i].Name),
                            Street: String(tData[i].Street),
                            City: String(tData[i].City),
                            District: String(tData[i].District),
                            State: String(tData[i].State),
                            Postalcode: String(tData[i].Postalcode),
                            Country: String(tData[i].Country),
                            Language: String(tData[i].Language),
                            Searchterm: String(tData[i].Searchterm),
                            Companycode: String(tData[i].Companycode),
                            Reconcacc: String(tData[i].Reconcacc),
                            Salesorg: String(tData[i].Salesorg),
                            Distchannel: String(tData[i].Distchannel),
                            Division: String(tData[i].Division),
                            Currency: String(tData[i].Currency),
                            Pricingproc: String(tData[i].Pricingproc),
                            Shippingcon: String(tData[i].Shippingcon),
                            Custgroup: String(tData[i].Custgroup),
                            Salesdist: String(tData[i].Salesdist),
                            Salesoffice: String(tData[i].Salesoffice),
                            Pricegroup: String(tData[i].Pricegroup),
                            Incoterms: String(tData[i].Incoterms),
                            Incotermsloc: String(tData[i].Incotermsloc),
                            Paymentterm: String(tData[i].Paymentterm),
                            Applevel: "L1",
                            Timestamp: "",
                            Status: "Rejected",
                            Remarks: String(tData[i].Remarks)
                        });
                    }
                    let payload = {
                        "Dummy": "X",
                        "Tobpitems": aitemss
                    }
                    // return;
                    /**
                     * @type {sap.ui.model.odata.v2.ODataModel}
                     */
                    var oModel = this.getOwnerComponent().getModel(),
                        oBusy = new sap.m.BusyDialog();
                    new sap.m.MessageBox.confirm("Are you realy want to reject?", {
                        action: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],

                        onClose: function (oAction) {
                            if (oAction === sap.m.MessageBox.Action.OK) {

                                oModel.create("/CreateDummySet", payload, {
                                    success: function (oData) {
                                        new sap.m.MessageBox.success("Rejected record has been updated successfully.");
                                        oBusy.close();
                                        this.getView().getModel("EmpTM1").refresh;
                                    },

                                    error: function (error) {
                                        // oBusy.close();
                                        // var responseText = JSON.parse(error.responseText);
                                        // var msg = responseText.error.message.value;
                                        // MessageBox.error(msg);
                                        oBusy.close();
                                        var responseText = error.responseText;
                                        if (responseText) {
                                            try {
                                                // Attempt to parse the responseText as JSON
                                                var responseJson = JSON.parse(responseText);
                                                var msg = responseJson.error.message.value;
                                                new sap.m.MessageBox.error(msg);
                                            } catch (e) {
                                                // If parsing fails, handle the error gracefully
                                                sap.m.MessageBox.error("An error occurred: " + responseText);
                                            }
                                        } else {
                                            // Handle cases where responseText is undefined or empty
                                            new sap.m.MessageBox.error("An unknown error occurred.");
                                        }
                                    }
                                });
                            }
                        }
                    });
                } else if (appData[0].Applevel === "L2") {
                    let aitemss = []
                    for (var i = 0; i < tData.length; i++) {
                        aitemss.push({
                            Customerno: String(tData[i].Customerno),
                            Custacctgroup: String(tData[i].Custacctgroup),
                            Pannumber: String(tData[i].Pannumber),
                            Title: String(tData[i].Title),
                            Name: String(tData[i].Name),
                            Street: String(tData[i].Street),
                            City: String(tData[i].City),
                            District: String(tData[i].District),
                            State: String(tData[i].State),
                            Postalcode: String(tData[i].Postalcode),
                            Country: String(tData[i].Country),
                            Language: String(tData[i].Language),
                            Searchterm: String(tData[i].Searchterm),
                            Companycode: String(tData[i].Companycode),
                            Reconcacc: String(tData[i].Reconcacc),
                            Salesorg: String(tData[i].Salesorg),
                            Distchannel: String(tData[i].Distchannel),
                            Division: String(tData[i].Division),
                            Currency: String(tData[i].Currency),
                            Pricingproc: String(tData[i].Pricingproc),
                            Shippingcon: String(tData[i].Shippingcon),
                            Custgroup: String(tData[i].Custgroup),
                            Salesdist: String(tData[i].Salesdist),
                            Salesoffice: String(tData[i].Salesoffice),
                            Pricegroup: String(tData[i].Pricegroup),
                            Incoterms: String(tData[i].Incoterms),
                            Incotermsloc: String(tData[i].Incotermsloc),
                            Paymentterm: String(tData[i].Paymentterm),
                            Applevel: "L2",
                            Timestamp: "",
                            Status: "Rejected",
                            Remarks: String(tData[i].Remarks)
                        });
                    }
                    let payload = {
                        "Dummy": "X",
                        "Tobpitems": aitemss
                    }
                    // return;
                    /**
                     * @type {sap.ui.model.odata.v2.ODataModel}
                     */
                    var oModel = this.getOwnerComponent().getModel(),
                        oBusy = new sap.m.BusyDialog();
                    oModel.create("/CreateDummySet", payload, {
                        success: function (oData) {
                            new sap.m.MessageBox.success("Rejected record has been updated successfully.");
                            oBusy.close();
                            this.getView().getModel("EmpTM1").refresh;
                        },
                        error: function (error) {
                            oBusy.close();
                            var responseText = error.responseText;
                            if (responseText) {
                                try {
                                    // Attempt to parse the responseText as JSON
                                    var responseJson = JSON.parse(responseText);
                                    var msg = responseJson.error.message.value;
                                    new sap.m.MessageBox.error(msg);
                                } catch (e) {
                                    // If parsing fails, handle the error gracefully
                                    sap.m.MessageBox.error("An error occurred: " + responseText);
                                }
                            } else {
                                // Handle cases where responseText is undefined or empty
                                new sap.m.MessageBox.error("An unknown error occurred.");
                            }
                        }
                    });
                }
            },

        });
    });
