sap.ui.define([
    "sap/ui/core/mvc/Controller",
    'sap/ui/model/json/JSONModel',
    'sap/ui/model/odata/v2/ODataModel',
    'sap/ui/export/library',
    'sap/ui/export/Spreadsheet',
    'sap/m/MessageToast',
    'sap/m/MessageBox',
    // 'sap/ui/core/format/DateFormat',
],
    function (Controller, JSONModel, ODataModel, Spreadsheet, library, MessageToast, MessageBox, DateFormat) {
        "use strict";

        var sServiceUrl = "/sap/opu/odata/sap/ZBP_CREATION_SRV_02";
        var oDataModel = ""; //new ODataModel(sServiceUrl, true);
        var dataUrl = "/CreateBPSet";

        

        return Controller.extend("project1.controller.View1", {
            onInit: function () {
                // console.log(XLSX)
                var oModel = new JSONModel({ data: [] });
                this.getView().setModel(oModel);
            },
            downloadTemplate: function () {
                // Define the column headers
                var columnHeaders = ["CustAcctGroup", "PANNO", "Title", "Name", "Street", "City", "District", "State", "PostalCode", "Country", "Language",
                    "SearchTerm1", "CompanyCode", "ReconcAcc", "Salesorg", "DistChannel", "Division", "Currency", "PricingProc", "ShipCond", "Custgroup",
                    "SalesDistrict", "SalesOffice", "Pricegroup", "IncoTerms", "IncoTermsLoc", "PaymentTerms"
                ];

                // Create a new workbook and worksheet
                var wb = XLSX.utils.book_new();
                var ws_data = [columnHeaders]; // only headers, no data
                var ws = XLSX.utils.aoa_to_sheet(ws_data);

                // Add the worksheet to the workbook
                XLSX.utils.book_append_sheet(wb, ws, "Template");

                // Generate Excel file and trigger download
                XLSX.writeFile(wb, "TableTemplate.xlsx");
                // MessageBox.success("Template Downloaded Successfully")
            },
            handleUploadPress: function (oEvent) {
                var oFileUploader = this.getView().byId("fileUploader");
                var oFile = oEvent.getParameter("files")[0];
                if (oFile && window.FileReader) {
                    var reader = new FileReader();
                    var that = this;
                    reader.onload = function (e) {
                        var data = e.target.result;
                        var workbook = XLSX.read(data, {
                            type: 'binary'
                        });
                        // Assuming the data is in the first sheet
                        var firstSheet = workbook.Sheets[workbook.SheetNames[0]];
                        var excelData = XLSX.utils.sheet_to_json(firstSheet, { header: 1 });

                        // Prepare the JSON data from Excel
                        var jsonData = [];
                        var headers = excelData[0]; // First row for headers
                        for (var i = 1; i < excelData.length; i++) {
                            var row = {};
                            for (var j = 0; j < headers.length; j++) {
                                row[headers[j]] = excelData[i][j];
                            }
                            jsonData.push(row); //Actual code 
                        }

                        // Update the model with the JSON data
                        var oModel = that.getView().getModel();
                        oModel.setProperty("/data", jsonData);
                    };
                    reader.readAsArrayBuffer(oFile);
                }
            },
            onSubmitButtonPress: function () {
                // var tData = this.getView().getModel().oData.data;
                var tData = this.getView().getModel().getProperty('/data');
                if(tData.length<=0){
                    sap.m.MessageBox.error("Please upload the file which contain at least one record for bp creation");
                    return
                }
                let aitemss =[]
                for (var i = 0; i < tData.length; i++) {
                    aitemss.push({
                        Customerno: "",
                        Custacctgroup: String(tData[i].CustAcctGroup),
                        Pannumber: String(tData[i].PANNO),
                        Title: String(tData[i].Title),
                        Name: String(tData[i].Name),
                        Street: String(tData[i].Street),
                        City: String(tData[i].City),
                        District: String(tData[i].District),
                        State: String(tData[i].State),
                        Postalcode: String(tData[i].PostalCode),
                        Country: String(tData[i].Country),
                        Language: String(tData[i].Language),
                        Searchterm: String(tData[i].SearchTerm1),
                        Companycode: String(tData[i].CompanyCode),
                        Reconcacc: String(tData[i].ReconcAcc),
                        Salesorg: String(tData[i].Salesorg),
                        Distchannel: String(tData[i].DistChannel),
                        Division: String(tData[i].Division),
                        Currency: String(tData[i].Currency),
                        Pricingproc: String(tData[i].PricingProc),
                        Shippingcon: String(tData[i].ShipCond),
                        Custgroup: String(tData[i].Custgroup),
                        Salesdist: String(tData[i].SalesDistrict),
                        Salesoffice: String(tData[i].SalesOffice),
                        Pricegroup: String(tData[i].Pricegroup),
                        Incoterms: String(tData[i].IncoTerms),
                        Incotermsloc: String(tData[i].IncoTermsLoc),
                        Paymentterm: String(tData[i].PaymentTerms),
                        // Timestamp: "",
                        Status: "Initiated"
                    });
                }
                let payload = {
                    "Dummy" : "X",
                    "Tobpitems" : aitemss
                  }
                // return;
                /**
                 * @type {sap.ui.model.odata.v2.ODataModel}
                 */
                var oModel = this.getOwnerComponent().getModel(),
                    oBusy = new sap.m.BusyDialog();
                oModel.create("/CreateBPSet", payload, {
                    success: function (oData) {
                        sap.m.MessageBox.success("Business Partner Creation Successfully.");
                        oBusy.close();
                    },
                    error: function (error) {
                        // oBusy.close();
                        // var responseText = JSON.parse(error.responseText);
                        // var msg = responseText.error.message.value;
                        // MessageBox.error(msg);
                        oBusy.close();

                        var responseText = error.responseText;
                        if (responseText) {
                            try {
                                // Attempt to parse the responseText as JSON
                                var responseJson = JSON.parse(responseText);
                                var msg = responseJson.error.message.value;
                                sap.m.MessageBox.error(msg);
                            } catch (e) {
                                // If parsing fails, handle the error gracefully
                                MessageBox.error("An error occurred: " + responseText);
                            }
                        } else {
                            // Handle cases where responseText is undefined or empty
                            MessageBox.error("An unknown error occurred.");
                        }
                    }
                });
            },
        });
    });
